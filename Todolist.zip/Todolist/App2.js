import React from 'react'

import TodoList from './components/TodoList'

const App2 = () => {
  return (
    <div>
      <TodoList/>
    </div>
  )
}

export default App2
