import React, { useState } from 'react'
import './todo.css'

const TodoList = () => {
    const[intial,setIntial] = useState();
    const[data, setData] = useState([])
    const getInput=(event)=>{
        setIntial(event.target.value )
    }
    const getData =()=>{
        console.log(intial)
        let store =[...data,intial]
        setData(store)
        setIntial("")
    }
    const deleteTask=  (index)=>{
      let filterData = data.filter((curElem,id)=>{
        return id != index
      })
      setData(filterData)

    }
  return (
    <div>
      <div className='container '>
        <div className='inputtask'>
            <input type='text' placeholder='Enter your Task' value={intial} onChange={getInput} />
            <button onClick={getData}>Add</button>
        </div>
        {data.map((curVal,index)=>{
          return(
            <>
            <div className='taskData'>
              <p>{curVal}</p>
              <button onClick={()=>deleteTask(index)}>Done</button>
            </div>
            </>
          )
        })}
      </div>
    </div>
  )
}

export default TodoList
