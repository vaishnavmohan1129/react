import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import InvoicePage from './pages/InvoicePage';
// import InvoicePage from './pages/InvoicePage';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<HomePage />} />
                {/* <Route path="/invoice" element={<Voice />} /> */}
                <Route path='/invoice' element={<InvoicePage/>}/>
            </Routes>
        </Router>
    );
}

export default App;
