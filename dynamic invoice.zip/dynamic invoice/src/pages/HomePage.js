import React from 'react';
import { useNavigate } from 'react-router-dom';
import img1 from '../images/logotc1.png';

function HomePage() {
    const navigate = useNavigate();

    const users = [
        { id: 1, name: 'User 1' },
        { id: 2, name: 'User 2' },
        { id: 3, name: 'User 3' },
        { id: 4, name: 'User 4' },
        { id: 5, name: 'User 5' },
    ];

    const handleNavigate = (userId) => {
        navigate('/invoice', { state: { userId } });
    };

    return (
        <div style={{ textAlign: 'center', marginTop: '10%' }}>
            <img src={img1} alt="Logo" />
            <h1>CPB Software</h1>
            <p style={{ marginBottom: '30px' }}>
                To get your tax invoice, click on the button corresponding to the user.
            </p>
            {users.map((user) => (
                <div key={user.id} style={{ marginBottom: '15px' }}>
                    <h3>{user.name}</h3>
                    <button
                        onClick={() => handleNavigate(user.id)}
                        style={{
                            padding: '10px 20px',
                            fontSize: '16px',
                            borderRadius: '30px',
                            cursor: 'pointer',
                        }}
                    >
                        View Invoice
                    </button>
                </div>
            ))}
        </div>
    );
}

export default HomePage;
