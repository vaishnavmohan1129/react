import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import img1 from '../images/logotc1.png';
import './Invoicepage.css';

function InvoicePage() {
    const { state } = useLocation();
    const { userId } = state || {};
    const [loader, setLoader] = useState(false);
    const [tableData, setTableData] = useState([]);
    const [totals, setTotals] = useState({ total: 0, vat: 0, gross: 0 });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('/services.json'); 
                const services = await response.json();
                const data = services.map((service) => ({
                    ...service,
                    quantity: Math.floor(Math.random() * 20), 
                    total: (Math.random() * service.baseAmount * 10).toFixed(2),
                }));

                setTableData(data);

                const totalAmount = data.reduce((sum, item) => sum + parseFloat(item.total), 0);
                const vat = (totalAmount * 0.19).toFixed(2); 
                const gross = (totalAmount + parseFloat(vat)).toFixed(2);

                setTotals({ total: totalAmount.toFixed(2), vat, gross });
            } catch (error) {
                console.error('Error fetching services:', error);
            }
        };

        fetchData();
    }, [userId]);

    const downloadPDF = () => {
        const capture = document.querySelector('.page');
        setLoader(true);
        html2canvas(capture).then((canvas) => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            setLoader(false);
            pdf.save('invoice.pdf');
        });
    };

    return (
        <div style={{ backgroundColor: 'black' }} className="main">
            <div className="page">
                <div className="top">
                    <div className="logo-container">
                        <img src={img1} alt="Logo" width="360px" />
                    </div>
                    <div className="text1">
                        <h6>CPB Software (Germany) GmbH</h6>
                        <p>Im Bruch 3, 63897 Miltenberg</p>
                        <p>Telefon: +49 4343 0</p>
                        <p>germany@cpb-software.com</p>
                        <p>www.cpb-software.com</p>
                    </div>
                </div>
                <h4>User No: {userId}</h4>
                <div className="tah">
                    <table>
                        <thead>
                            <tr>
                                <th>Service Description</th>
                                <th>Amount -without VAT-</th>
                                <th>Quantity</th>
                                <th>Total Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tableData.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.description}</td>
                                    <td>{item.baseAmount.toFixed(2)} €</td>
                                    <td>{item.quantity}</td>
                                    <td>{item.total} €</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="tbh3">
                    <tr>
                        <td id="a">Total</td>
                        <td id="d">{totals.total} €</td>
                    </tr>
                    <tr>
                        <td id="b">VAT 19 %</td>
                        <td>{totals.vat} €</td>
                    </tr>
                    <tr>
                        <td id="c">Gross Amount incl. VAT</td>
                        <td>{totals.gross} €</td>
                    </tr>
                </div>

                <div className="lastpart">
                    <p>Terms of Payment: Immediate payment without discount. Any bank charges must be paid by the invoice recipient.</p>
                    <p>Bank fees at our expense will be charged to the invoice recipient!</p>
                    <p id="e">Please credit the amount invoiced to IBAN DE29 1234 5678 9012 3456 78 | BIC GENODE51MIC (SEPA Credit Transfer)</p>
                    <p id="f">This invoice is generated automatically and will not be signed</p>
                </div>
            </div>
            <div className="receipt-actions-div">
                <div className="actions-right">
                    <button
                        className="download-button"
                        onClick={downloadPDF}
                        disabled={loader}
                    >
                        {loader ? <span>Downloading...</span> : <span>Download PDF</span>}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default InvoicePage;
