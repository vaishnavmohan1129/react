import express from 'express';
import con from '../utils/db.js';
import jwt from 'jsonwebtoken';
const router = express.Router();
import bcrypt from 'bcrypt'



router.get('/category', (req, res) => {
  const sql = "SELECT * FROM category";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      else{
      return res.json({Status: true, Result: result})
    }
  })
})

router.post('/add_category', (req, res) => {
  const categoryName = req.body.category;
   const checkSql = "SELECT COUNT(*) AS count FROM category WHERE name = ?";
  con.query(checkSql, [categoryName], (err, result) => {
    if (err) return res.json({Status: false, Error: "Query Error"});

    if (result[0].count > 0) {
     
      return res.json({Status: false, Error: "Category already exists"});
    } else {
      
      const insertSql = "INSERT INTO category (name) VALUES (?)";
      con.query(insertSql, [categoryName], (err, result) => {
        if (err) return res.json({Status: false, Error: "Query Error"});
        return res.json({Status: true});
      });
    }
  });
});

router.post('/add_employee', (req, res) => {
  const sql = `INSERT INTO employee 
  (name,email,password, role, category_id) 
  VALUES (?)`;
  bcrypt.hash(req.body.password, 10, (err, hash) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      const values = [
          req.body.name,
          req.body.email,
          hash,
          req.body.role,
          
          req.body.category_id
      ]
      con.query(sql, [values], (err, result) => {
          if(err) return res.json({Status: false, Error: err})
          return res.json({Status: true})
      })
  })
})

//for employee




// router.post("/login", (req, res) => {
//     const { email, password } = req.body;

//     const query = "SELECT * FROM employee WHERE email = ?";
//     con.query(query, [email], (err, result) => {
//         if (err) {
//             return res.json({ loginStatus: false, Error: "Query error" });
//         }

//         if (result.length > 0) {
//             const user = result[0];
//             bcrypt.compare(password, user.password, (err, isMatch) => {
//                 if (err) {
//                     return res.json({ loginStatus: false, Error: "Error comparing passwords" });
//                 }

//                 if (isMatch) {
//                     const token = jwt.sign(
//                         { role: user.role, email: user.email },
//                         "jwt_secret_key",
//                         { expiresIn: "1d" }
//                     );
//                     res.cookie('token', token);
//                     // Navigate to different routes based on the role
//                     if (user.role === 'employee') {
//                         return res.json({ loginStatus: true, role: "employee" });
//                     } else  if(user.role === 'admin'){
//                         return res.json({ loginStatus: true, role: "admin" });
//                     }
//                     else  if(user.role === 'manager'){
//                       return res.json({ loginStatus: true, role: "manager" });
//                   }
//                 } else {
//                     return res.json({ loginStatus: false, Error: "Wrong email or password" });
//                 }
//             });
//         } else {
//             return res.json({ loginStatus: false, Error: "Wrong email or password" });
//         }
//     });
// });


router.get('/employee', (req, res) => {
  const sql = "SELECT * FROM employee";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true, Result: result})
  })
})

router.get('/employee/:id', (req, res) => {
  const id = req.params.id;
  const sql = "SELECT * FROM employee WHERE id = ?";
  con.query(sql,[id], (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true, Result: result})
  })
})

router.put('/edit_employee/:id', (req, res) => {
  const id = req.params.id;
  const sql = `UPDATE employee 
      set name = ?, email = ?, role = ?, category_id = ? 
      Where id = ?`
  const values = [
      req.body.name,
      req.body.email,
      req.body.role,
      req.body.category_id
  ]
  con.query(sql,[...values, id], (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"+err})
      return res.json({Status: true, Result: result})
  })
})

router.delete('/delete_employee/:id', (req, res) => {
  const id = req.params.id;
  const sql = "delete from employee where id = ?"
  con.query(sql,[id], (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"+err})
      return res.json({Status: true, Result: result})
  })
})

//adminrouter
router.get('/employee_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS employee FROM employee WHERE role = 'employee'";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error: " + err });
    return res.json({ Status: true, Result: result });
  });
});


router.get('/tas_count', (req, res) => {
  const sql = "SELECT COUNT(emp_id) AS employee FROM task ";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error: " + err });
    return res.json({ Status: true, Result: result });
  });
});



router.get('/admin_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS admin FROM employee WHERE role = 'admin'";
  con.query(sql, (err, result) => {
      if (err) return res.json({ Status: false, Error: "Query Error " + err });
      return res.json({ Status: true, Result: result });
  });
});
router.get('/admin_records', (req, res) => {
  const sql = "SELECT * FROM employee WHERE role = 'admin'";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"+err})
      return res.json({Status: true, Result: result})
  })
})

router.get('/logout', (req, res) => {
    res.clearCookie('token')
    return res.json({Status: true})
})


router.get('/updates', (req, res) => {
  const sql = "SELECT * FROM updates";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true, Result: result})
  })
})

router.post('/add_updates', (req, res) => {
  const sql = "INSERT INTO updates (`name`) VALUES (?)"
  con.query(sql, [req.body.updates], (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true})
  })
})


router.get('/employee', (req, res) => {
  
  const sql = 'SELECT name FROM employee WHERE id = ?'; 
  const employeeId = req.query.id; 

  con.query(sql, [employeeId], (err, result) => {
      if (err) return res.json({ Status: false, Error: "Query Error" });
      if (result.length > 0) {
          return res.json({ Status: true, Name: result[0].name });
      } else {
          return res.json({ Status: false, Error: "Employee not found" });
      }
  });
});

router.get('/ad_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS admin FROM updates";
  con.query(sql, (err, result) => {
      if (err) return res.json({ Status: false, Error: "Query Error " + err });
      return res.json({ Status: true, Result: result });
  });
});



router.get('/issue', (req, res) => {
  const sql = "SELECT * FROM issues";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true, Result: result})
  })
})

router.get('/employees', (req, res) => {
  const sql = "SELECT * FROM employee where role='employee'";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      return res.json({Status: true, Result: result})
  })
})

router.post('/add_issues', (req, res) => {
  const sql = "INSERT INTO issues (`name`) VALUES (?)";
  con.query(sql, [req.body.updates], (err, result) => {
      if (err) {
          console.error(err);
          return res.json({ Status: false, Error: "Query Error" });
      }
      return res.json({ Status: true });
  });
});
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  const query = "SELECT * FROM employee WHERE email = ?";
  con.query(query, [email], (err, result) => {
      if (err) {
          return res.json({ loginStatus: false, Error: "Query error" });
      }

      if (result.length > 0) {
          const user = result[0];
          bcrypt.compare(password, user.password, (err, isMatch) => {
              if (err) {
                  return res.json({ loginStatus: false, Error: "Error comparing passwords" });
              }

              if (isMatch) {
                  const token = jwt.sign(
                      { role: user.role, email: user.email },
                      "jwt_secret_key", // Replace with your secret key
                      { expiresIn: "1d" }
                  );
                  res.cookie('token', token, { httpOnly: true });
                  // Navigate to different routes based on the role
                  if (user.role === 'employee') {
                      return res.json({ loginStatus: true, role: "employee" });
                  } else if (user.role === 'admin') {
                      return res.json({ loginStatus: true, role: "admin" });
                  } else if (user.role === 'manager') {
                      return res.json({ loginStatus: true, role: "manager" });
                  } else {
                      return res.json({ loginStatus: false, Error: "Unknown role" });
                  }
              } else {
                  return res.json({ loginStatus: false, Error: "Wrong email or password" });
              }
          });
      } else {
          return res.json({ loginStatus: false, Error: "Wrong email or password" });
      }
  });
});

// router.get('/employees', (req, res) => {
//   db.query("SELECT * FROM employee where role='employee'", (err, results) => {
//     if (err) throw err;
//     res.json(results);
//   });
// });


// mashboard
// router.get('/employees', (req, res) => {
//   db.query('SELECT * FROM employee WHERE role = ?', ['employee'], (err, results) => {
//     if (err) {
//       return res.status(500).json({ Status: false, Error: 'Query Error' });
//     }
//     res.json({ Status: true, Result: results });
//   });
// });

router.post('/add_task', (req, res) => {
  const sql = `INSERT INTO task (name, date, info, emp_id) VALUES (?, ?, ?, ?)`;
  const values = [
    req.body.name,
    req.body.date,
    req.body.info,
    req.body.emp_id
  ];
  con.query(sql, values, (err, result) => {
    if (err) {
      return res.json({Status: false, Error: err});
    }
    return res.json({Status: true});
  });
});

router.get('/taskshow', (req, res) => {
  const sql = "SELECT * FROM task";
  con.query(sql, (err, result) => {
      if(err) return res.json({Status: false, Error: "Query Error"})
      else{
      return res.json({Status: true, Result: result})
    }
  })
})

router.get('/tasks', (req, res) => {
  const empId = req.params.emp_id;
  const sql = "SELECT * FROM task";
  con.query(sql, [empId], (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error" });
    return res.json({ Status: true, Result: result });
  });
});
router.put('/task/:id', (req, res) => {
  const taskId = req.params.id;
  const { name, date, info, emp_id } = req.body;
  const sql = "UPDATE task SET name = ?, date = ?, info = ?, emp_id = ? WHERE id = ?";
  con.query(sql, [name, date, info, emp_id, taskId], (err, result) => {
    if (err) return res.json({ Status: false, Error: "Update Error" });
    return res.json({ Status: true });
  });
});

router.put('/update_task_status/:id', (req, res) => {
  const taskId = req.params.id;
  const { status } = req.body;
  const sql = "UPDATE task SET status = ? WHERE id = ?";
  con.query(sql, [status, taskId], (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error" });
    return res.json({ Status: true });
  });
});

// router.get('/pro_records', (req, res) => {
//   const sql = "SELECT * FROM task ";
//   con.query(sql, (err, result) => {
//       if(err) return res.json({Status: false, Error: "Query Error"+err})
//       return res.json({Status: true, Result: result})
//   })
// })

router.get('/pro_records', (req, res) => {
  const sql = "SELECT * FROM task WHERE status IN ('In Process', 'Not Completed')";
  con.query(sql, (err, result) => {
    if(err) return res.json({Status: false, Error: "Query Error: " + err});
    return res.json({Status: true, Result: result});
  });
});


router.get('/pen_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS employee FROM task WHERE status = 'Not Completed'";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error: " + err });
    return res.json({ Status: true, Result: result });
  });
});


// router.get('/tasks', (req, res) => {
//   const id = req.params.id;
//   const sql = "SELECT * FROM task WHERE emp_id = ?";
//   con.query(sql,[id], (err, result) => {
//       if(err) return res.json({Status: false, Error: "Query Error"})
//       return res.json({Status: true, Result: result})
//   })
// })


router.get('/task_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS ttask FROM task";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error " + err });
    return res.json({ Status: true, Result: result });
  });
});


router.get('/pend_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS ptask FROM task WHERE status = 'Not Completed' OR status = 'In Process'";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error " + err });
    return res.json({ Status: true, Result: result });
  });
});


router.get('/com_count', (req, res) => {
  const sql = "SELECT COUNT(id) AS ctask FROM task WHERE status = 'Completed'";
  con.query(sql, (err, result) => {
    if (err) return res.json({ Status: false, Error: "Query Error " + err });
    return res.json({ Status: true, Result: result });
  });
});


router.get('/pr_records', (req, res) => {
  const sql = "SELECT * FROM task WHERE status = 'Completed'";
  con.query(sql, (err, result) => {
    if(err) return res.json({Status: false, Error: "Query Error: " + err});
    return res.json({Status: true, Result: result});
  });
});


export { router as adminRouter };



