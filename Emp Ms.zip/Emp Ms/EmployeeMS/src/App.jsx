import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/Login'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Dashboard from './Components/Dashboard';
import Home from './Components/Home';
import Employee from './Components/Employee';
import Category from './Components/Category';
import Profile from './Components/Profile';
import AddCategory from './Components/AddCategory';
import AddEmployee from './Components/AddEmployee';
import Homepage from './Components/Homepage';
import EmployeeLogin from './Components/EmployeeLogin';
import TaskDashboard from './Components/TaskDashboard';
import EditEmployee from './Components/EditEmployee';
import Updates from './Components/Updates';
import Addupdates from './Components/AddUpdates';
import EmpUpdates from './Components/EmpUpdates';
import EmpHome from './Components/EmpHome';
import EmployeeChat from './Components/EmployeeChat';
import Addissues from './Components/Addissue';
import Adminissue from './Components/Adminissue';
import ReplyPage from './Components/ReplyPage';
import Mashboard from './Components/Mashboard';
import Task from './Components/Task';
import ListTask from './Components/ListTask';
import EmpTask from './Components/EmpTask';
import EmpTasks from './Components/EmpTask';
import MangHome from './Components/MangHome';
// import Task from './Components/Task';

function App() {
  
  return (
  <BrowserRouter>
  <Routes>
   
    <Route path='/adminlogin' element={<Login/>}></Route>
    <Route path='/employeelogin' element={<EmployeeLogin/>}></Route>
    
    <Route path="/tashboard" element={<TaskDashboard />} >
    
    <Route path='' element={<EmpHome/>}></Route>
    <Route path='/tashboard/empupdates'element={<EmpUpdates />} />
    <Route path="/tashboard/emptask" element={<EmpTasks />} />

    
    <Route path='/tashboard/empiss'element={<EmployeeChat />} />
    <Route path='/tashboard/issues' element={<Addissues/>}></Route>
    </Route>
    <Route path='/dashboard' element={<Dashboard/>}>
    <Route path='' element={<Home/>}></Route>
    <Route path='/dashboard/employee' element={<Employee/>}></Route>
    <Route path='/dashboard/Category' element={<Category/>}></Route>
    <Route path='/dashboard/profile' element={<Profile/>}></Route>
    <Route path='/dashboard/add_category' element={<AddCategory/>}></Route>
    <Route path='/dashboard/add_employee' element={<AddEmployee/>}></Route>
    <Route path='/dashboard/updates' element={<Updates/>}></Route>
    <Route path='/dashboard/add_updates' element={<Addupdates/>}></Route>
    <Route path='/dashboard/amissue' element={<Adminissue/>}></Route>
    <Route path="/dashboard/reply" element={<ReplyPage />} />
    
    <Route path='/dashboard/edit_employee/:id' element={<EditEmployee />}>
    </Route>
    </Route> 
    <Route path="/mashboard" element={<Mashboard/>}>
    <Route path='' element={<MangHome/>}></Route>
    <Route path='/mashboard/task' element={<Task/>}></Route>
    <Route path='/mashboard/listtask' element={<ListTask/>}></Route>
    </Route> 
  </Routes>
  </BrowserRouter>
  )
}

export default App
