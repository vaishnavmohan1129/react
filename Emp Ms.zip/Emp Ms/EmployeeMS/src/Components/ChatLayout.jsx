import React from 'react';
import { Link, Outlet } from 'react-router-dom';

function ChatLayout() {
    return (
        <div>
            <nav>
                <ul>
                    <li><Link to="/employee-chat">Employee Chat</Link></li>
                    <li><Link to="/admin-chat">Admin Chat</Link></li>
                </ul>
            </nav>
            <Outlet />
        </div>
    );
}

export default ChatLayout;
