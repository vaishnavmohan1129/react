import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const Adminissue = () => {
    const [updates, setUpdates] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3000/auth/issue')
            .then(result => {
                if (result.data.Status) {
                    setUpdates(result.data.Result);
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.log(err));
    }, []);

    return (
        <div className='px-5 mt-3'>
            <div className='d-flex justify-content-center'>
                <h3>Issues</h3>
            </div>
            
            <div className='row mt-5'>
                {updates.map((update, index) => (
                    <div className='col-md-4 mb-3' key={index}>
                        <div className='card'>
                            <div className='card-body'>
                                <h5 className='card-title'>Issue {index + 1}</h5>
                                <p className='card-text'>{update.name}</p>
                                <Link 
                                    to="/dashboard/reply"
                                    className='btn btn-primary'>
                                    Reply
                                </Link>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Adminissue;
