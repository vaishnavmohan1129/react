import React from 'react'
import './home.css'
import { useNavigate } from 'react-router-dom';

const Homepage = () => {
    
        const navigate = useNavigate();
      
        const handleAdminLogin = () => {
          navigate('/adminlogin');
        };
      
        const handleEmployeeLogin = () => {
          navigate('/employeelogin');
        };
      
  return (
    <div className="matop">
    <div className="d-flex flex-column align-items-center mt-5 matop">
    <h1>Welcome</h1>
    <button className="btn btn-primary m-2" onClick={handleAdminLogin}>
      Login as Admin
    </button>
    <button className="btn btn-secondary m-2" onClick={handleEmployeeLogin}>
      Login as Employee
    </button>
  </div>
  </div>
  )
}

export default Homepage
