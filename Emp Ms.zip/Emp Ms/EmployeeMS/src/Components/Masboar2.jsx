import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Mashboard = () => {
  const [employee, setEmployee] = useState({
    name: "",
    date: "",
    info: "",
    emp_id: "",
  });

  const [category, setCategory] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:3000/auth/task")
      .then((result) => {
        if (result.data.Status) {
          setCategory(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch((err) => console.log(err));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:3000/auth/add_task", employee)
      .then((result) => {
        if (result.data.Status) {
          alert("Task Done");
          navigate("/");
        } else {
          alert(result.data.Error);
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="d-flex justify-content-center align-items-center mt-5">
      <div className="p-3 rounded w-50 border">
        <h3 className="text-center">Add Task</h3>
        <form className="row g-1" onSubmit={handleSubmit}>
          <div className="col-12">
            <label htmlFor="inputName" className="form-label">
              Task
            </label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputName"
              placeholder="Enter Task"
              value={employee.name}
              onChange={(e) =>
                setEmployee({ ...employee, name: e.target.value })
              }
            />
          </div>
          <div className="col-12">
            <label htmlFor="inputDate" className="form-label">
              Last Date
            </label>
            <input
              type="date"
              className="form-control rounded-0"
              id="inputDate"
              placeholder="Enter Last Date"
              value={employee.date}
              onChange={(e) =>
                setEmployee({ ...employee, date: e.target.value })
              }
            />
          </div>
          <div className="col-12">
            <label htmlFor="inputInfo" className="form-label">
              Additional Information
            </label>
            <input
              type="text"
              className="form-control rounded-0"
              id="inputInfo"
              placeholder=""
              value={employee.info}
              onChange={(e) =>
                setEmployee({ ...employee, info: e.target.value })
              }
            />
          </div>
          <div className="col-12">
            <label htmlFor="category" className="form-label">
              Department
            </label>
            <select
              name="category"
              id="category"
              className="form-select"
              value={employee.emp_id}
              onChange={(e) =>
                setEmployee({ ...employee, emp_id: e.target.value })
              }
            >
              <option value="">Select Department</option>
              {category.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="col-12 mt-3">
            <button type="submit" className="btn btn-primary w-100">
              Add Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Mashboard;
