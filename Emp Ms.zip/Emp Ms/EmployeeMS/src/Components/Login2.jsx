import React, { useState } from 'react'
import './style.css'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const Login = () => {
    const [values, setValues] = useState({
        email: '',
        password: ''
    })
    const [error , setError] = useState(null)
    const navigate = useNavigate()
    axios.defaults.withCredentials = true;

    const handleSubmit = (event) => {
        event.preventDefault()
        axios.post('http://localhost:3000/auth/login', values)
       .then(result => {
        if(result.data.loginStatus){
            if (result.data.role === 'admin') {
                navigate('/dashboard')
            } else if (result.data.role === 'employee') {
                navigate('/tashboard') 
            }
        } else{
            setError(result.data.Error)
        }
       })
       .catch(err => console.log(err))
    }

  return (
    <div className='d-flex justify-content-center align-items-center vh-100 loginPage'>
        <div className='p-3 rounded w-25 border loginForm'>
        <div className='text-danger'>
                    {error && error}
                </div>
            <h2>Login Page</h2>
            <form onSubmit={handleSubmit}>
                <div className='mb-3'>
                    <label htmlFor="email"><strong>Email:</strong></label>
                    <input type="email" name='email' autoComplete='off' placeholder='Enter Email'
                     onChange={(e) => setValues({...values, email : e.target.value})} className='form-control rounded-0'/>
                </div>
                <div className='mb-3'> 
                    <label htmlFor="password"><strong>Password:</strong></label>
                    <input type="password" name='password' placeholder='Enter Password'
                     onChange={(e) => setValues({...values, password : e.target.value})} className='form-control rounded-0'/>
                </div>
                <button className='btn btn-success w-100 rounded-0 mb-2'>Log in</button>
                <div className='mb-1'> 
                    <input type="checkbox" name="tick" id="tick" className='me-2'/>
                    <label htmlFor="password">You are Agree with terms & conditions</label>
                </div>
            </form>
        </div>
    </div>
  )
}

export default Login


//backend 

router.post("/login", (req, res) => {
    const { email, password } = req.body;
  
   
    const adminQuery = "SELECT * FROM admin WHERE email = ?";
    con.query(adminQuery, [email], (err, adminResult) => {
        if (err) {
            return res.json({ loginStatus: false, Error: "Query error" });
        }
  
        if (adminResult.length > 0) {
            const admin = adminResult[0];
            if (admin.password === password) {
                const token = jwt.sign(
                    { role: "admin", email: admin.email },
                    "jwt_secret_key",
                    { expiresIn: "1d" }
                );
                res.cookie('token', token);
                return res.json({ loginStatus: true, role: "admin" });
            } else {
                return res.json({ loginStatus: false, Error: "Wrong email or password" });
            }
        } else {
          
            const employeeQuery = "SELECT * FROM employee WHERE email = ?";
            con.query(employeeQuery, [email], (err, employeeResult) => {
                if (err) {
                    return res.json({ loginStatus: false, Error: "Query error" });
                }
  
                if (employeeResult.length > 0) {
                    const user = employeeResult[0];
                    bcrypt.compare(password, user.password, (err, isMatch) => {
                        if (err) {
                            return res.json({ loginStatus: false, Error: "Error comparing passwords" });
                        }
  
                        if (isMatch) {
                            const token = jwt.sign(
                                { role: "employee", email: user.email },
                                "jwt_secret_key",
                                { expiresIn: "1d" }
                            );
                            res.cookie('token', token);
                            return res.json({ loginStatus: true, role: "employee" });
                        } else {
                            return res.json({ loginStatus: false, Error: "Wrong email or password" });
                        }
                    });
                } else {
                    return res.json({ loginStatus: false, Error: "Wrong email or password" });
                }
            });
        }
    });
  });