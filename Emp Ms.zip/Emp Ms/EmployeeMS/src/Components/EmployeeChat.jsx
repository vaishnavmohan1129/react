import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const EmployeeChat = () => {
    const [updates, setupdates] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3000/auth/issue')
            .then(result => {
                if (result.data.Status) {
                    setupdates(result.data.Result);
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.log(err));
    }, []);

    return (
        <div className='px-5 mt-3'>
            <div className='d-flex justify-content-center'>
                <h3>Issues</h3>
            </div>
            <Link to="/tashboard/issues" className='btn btn-success mb-3'>Add Issues</Link>
            <div className='row'>
                {updates.map((update, index) => (
                    <div className='col-md-4 mb-3' key={index}>
                        <div className='card'>
                            <div className='card-body'>
                                <h5 className='card-title'>Issues {index + 1}</h5>
                                <p className='card-text'>{update.name}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default EmployeeChat;
