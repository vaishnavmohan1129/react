import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MangHome = () => {
  const [tasks, setTasks] = useState([]);
  const [tsvTotal, setTsvTotal] = useState(0);
  const [pendingTasksCount, setPendingTasksCount] = useState(0);
  const [completedTasksCount, setCompletedTasksCount] = useState(0);
  const [pros, setPros] = useState([]);

  useEffect(() => {
    tsvCount();
    pendCount();
    comCount();
    proRecords();
  }, []);


  const proRecords = () => {
    axios.get('http://localhost:3000/auth/pr_records')
        .then(result => {
            if(result.data.Status) {
                setPros(result.data.Result);
            } else {
                alert(result.data.Error);
            }
        });
};


  const tsvCount = () => {
    axios.get('http://localhost:3000/auth/task_count')
      .then(result => {
        if (result.data.Status) {
          setTsvTotal(result.data.Result[0].ttask);
        }
      })
      .catch(error => {
        console.error('Error fetching task count:', error);
      });
  };

  const pendCount = () => {
    axios.get('http://localhost:3000/auth/pend_count')
      .then(result => {
        if (result.data.Status) {
          setPendingTasksCount(result.data.Result[0].ptask);
        }
      })
      .catch(error => {
        console.error('Error fetching pending task count:', error);
      });
  };

  const comCount = () => {
    axios.get('http://localhost:3000/auth/com_count')
      .then(result => {
        if (result.data.Status) {
          setCompletedTasksCount(result.data.Result[0].ctask);
        }
      })
      .catch(error => {
        console.error('Error fetching completed task count:', error);
      });
  };

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/ta'); 
        const allTasks = response.data;
        setTasks(allTasks);
      } catch (error) {
        console.error('Error fetching tasks:', error);
      }
    };

    fetchTasks();
  }, []);

  return (
    <div>
      <div className='p-3 d-flex justify-content-around mt-3'>
        <div className='px-3 pt-2 pb-3 border shadow-sm w-25'>
          <div className='text-center pb-1'>
            <h4>Total Task</h4>
          </div>
          <hr />
          <div className='d-flex justify-content-between'>
            <h5>Total:</h5>
            <h5>{tsvTotal}</h5>
          </div>
        </div>
        <div className='px-3 pt-2 pb-3 border shadow-sm w-25'>
          <div className='text-center pb-1'>
            <h4>Pending Tasks</h4>
          </div>
          <hr />
          <div className='d-flex justify-content-between'>
            <h5>Total:</h5>
            <h5>{pendingTasksCount}</h5>
          </div>
        </div>
        <div className='px-3 pt-2 pb-3 border shadow-sm w-25'>
          <div className='text-center pb-1'>
            <h4>Completed Tasks</h4>
          </div>
          <hr />
          <div className='d-flex justify-content-between'>
            <h5>Total:</h5>
            <h5>{completedTasksCount}</h5>
          </div>
        </div>
      </div>
      <h3 style={{ marginTop: '90px', marginLeft: '30px' }}>List of Completed Tasks:</h3>
      <div className='mt-4 px-5 pt-3'>
                {/* <h3>List of Tasks to Complete</h3> */}
                <table className='table'>
                    <thead>
                        <tr>
                            <th>Task</th>
                            
                            <th>Employee ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {pros.map(a => (
                            <tr key={a.id}>
                                <td>{a.name}</td>
                               
                                <td>{a.emp_id}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
    </div>
  );
};

export default MangHome;
