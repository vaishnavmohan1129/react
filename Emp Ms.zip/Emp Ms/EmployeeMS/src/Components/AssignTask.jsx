import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AssignTask = () => {
  const [employees, setEmployees] = useState([]);
  const [description, setDescription] = useState('');
  const [employeeId, setEmployeeId] = useState('');

  useEffect(() => {
    axios.get('/api/employees')
      .then(res => setEmployees(res.data.Result)) // Adjusted to use `Result` key
      .catch(err => console.error(err));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/api/tasks', { description, employee_id: employeeId })
      .then(() => {
        setDescription('');
        setEmployeeId('');
        alert('Task assigned successfully');
      })
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Assign Task</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Description:</label>
          <input 
            type="text" 
            value={description} 
            onChange={(e) => setDescription(e.target.value)} 
          />
        </div>
        <div>
          <label>Employee:</label>
          <select 
            value={employeeId} 
            onChange={(e) => setEmployeeId(e.target.value)}
          >
            <option value="">Select an employee</option>
            {employees.map(emp => (
              <option key={emp.id} value={emp.id}>{emp.name}</option>
            ))}
          </select>
        </div>
        <button type="submit">Assign Task</button>
      </form>
    </div>
  );
};

export default AssignTask;
