import React from 'react'

const AdminLogin = () => {
  return (
    <div>
      
    <div>
      <h2>Admin Login Page</h2>
      {/* Add your admin login form here */}
    </div>

    </div>
  )
}

export default AdminLogin
