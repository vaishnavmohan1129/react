import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const EmpTasks = () => {
  const { emp_id } = useParams();
  const [tasks, setTasks] = useState([]);
  const [timeValues, setTimeValues] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:3000/auth/tasks`)
      .then(result => {
        if (result.data.Status) {
          setTasks(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(error => {
        console.error("Error fetching data: ", error);
      });
  }, [emp_id]);

  const handleStatusChange = (taskId, status) => {
    axios.put(`http://localhost:3000/auth/update_task_status/${taskId}`, { status })
      .then(res => {
        if (res.data.Status) {
          alert("Status updated successfully");
          setTasks(tasks.map(task => 
            task.id === taskId ? { ...task, status } : task
          ));
        } else {
          alert(res.data.Error);
        }
      })
      .catch(err => {
        console.error("Error updating status: ", err);
      });
  };

  const handleTimeChange = (taskId, value) => {
    setTimeValues({
      ...timeValues,
      [taskId]: value
    });
  };

  const handleSaveTime = (taskId) => {
    const time = timeValues[taskId];
    if (time) {
      axios.put(`http://localhost:3000/auth/update_task_time/${taskId}`, { time })
        .then(res => {
          if (res.data.Status) {
            alert("Time updated successfully");
            setTasks(tasks.map(task => 
              task.id === taskId ? { ...task, time } : task
            ));
            setTimeValues(prev => {
              const updated = { ...prev };
              delete updated[taskId];
              return updated;
            });
          } else {
            alert(res.data.Error);
          }
        })
        .catch(err => {
          console.error("Error updating time: ", err);
        });
    }
  };

  return (
    <div className="px-5 mt-3">
      <div className="d-flex justify-content-center">
        <h3>Tasks for Employee {emp_id}</h3>
      </div>
      <div className="mt-3">
        <table className="table">
          <thead>
            <tr>
              <th>Task</th>
              <th>Estimated Date</th>
              <th>Info</th>
              <th>Status</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, i) => (
              <tr key={i}>
                <td>{task.name}</td>
                <td>{task.date}</td>
                <td>{task.info}</td>
                <td>
                  <select
                    value={task.status || 'Not Completed'} // Default value
                    onChange={(e) => handleStatusChange(task.id, e.target.value)}
                  >
                    <option value="Not Completed">Not Completed</option>
                    <option value="In Process">In Process</option>
                    <option value="Completed">Completed</option>
                  </select>
                </td>
                <td>
                  <input
                    type="text"
                    value={timeValues[task.id] || ''}
                    onChange={(e) => handleTimeChange(task.id, e.target.value)}
                    placeholder="Enter time"
                  />
                  <button onClick={() => handleSaveTime(task.id)}>Save</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmpTasks;
