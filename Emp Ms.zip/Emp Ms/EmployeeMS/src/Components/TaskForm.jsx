import React, { useState, useEffect } from 'react';

const TaskForm = ({ addTask, editTask, currentTask }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (currentTask) {
      setName(currentTask.name);
      setDescription(currentTask.description);
    } else {
      setName('');
      setDescription('');
    }
  }, [currentTask]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (currentTask) {
      editTask({ id: currentTask.id, name, description });
    } else {
      addTask({ name, description });
    }
  };

  return (
    <div>
      <h2>{currentTask ? 'Edit Task' : 'Add Task'}</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Task Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Task Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <button type="submit">{currentTask ? 'Update' : 'Add'}</button>
      </form>
    </div>
  );
};

export default TaskForm;
