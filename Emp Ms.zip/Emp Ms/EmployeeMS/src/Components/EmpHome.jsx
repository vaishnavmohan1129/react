import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const EmpHome = () => {
    const navigate = useNavigate();
    const [employeeTotal, setEmployeeTotal] = useState(0);
    const [adminTotal, setAdminTotal] = useState(0);
    const [taskTotal, setTaskTotal] = useState(0);
    const [pros, setPros] = useState([]);

    useEffect(() => {
        employeeCount();
        adminCount();
        taskCount();
        proRecords();
    }, []);

    const employeeCount = () => {
        axios.get('http://localhost:3000/auth/pen_count')
            .then(result => {
                if(result.data.Status) {
                    setEmployeeTotal(result.data.Result[0].employee);
                }
            });
    };

    const adminCount = () => {
        axios.get('http://localhost:3000/auth/ad_count')
            .then(result => {
                if(result.data.Status) {
                    setAdminTotal(result.data.Result[0].admin);
                }
            });
    };

    const taskCount = () => {
        axios.get('http://localhost:3000/auth/tas_count')
            .then(result => {
                if(result.data.Status) {
                    setTaskTotal(result.data.Result[0].total);
                }
            });
    };

    const handleDivClick = () => {
        navigate('/tashboard/empupdates');
    };

    const proRecords = () => {
        axios.get('http://localhost:3000/auth/pro_records')
            .then(result => {
                if(result.data.Status) {
                    setPros(result.data.Result);
                } else {
                    alert(result.data.Error);
                }
            });
    };

    return (
        <div>
            <div className='p-3 d-flex justify-content-around mt-3'>
                <div className='px-3 pt-2 pb-3 border shadow-sm w-25'>
                    <div className='text-center pb-1' onClick={handleDivClick} style={{ cursor: 'pointer' }}>
                        <h4>Updates</h4>
                    </div>
                    <hr />
                    <div className='d-flex justify-content-between'>
                        <h5>Total:</h5>
                        <h5>{adminTotal}</h5>
                    </div>
                </div>
                <div className='px-3 pt-2 pb-3 border shadow-sm w-25'>
                    <div className='text-center pb-1'>
                        <h4>Pending Tasks</h4>
                    </div>
                    <hr />
                    <div className='d-flex justify-content-between'>
                        <h5>Total:</h5>
                        <h5>{employeeTotal}</h5>
                    </div>
                </div>
            </div>
            <div className='mt-4 px-5 pt-3'>
                <h3>List of Tasks to Complete</h3>
                <table className='table'>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Last Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {pros.map(a => (
                            <tr key={a.id}>
                                <td>{a.name}</td>
                                <td>{a.date}</td>
                                <td>{a.status}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default EmpHome;
