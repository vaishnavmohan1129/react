import React from 'react'

const Profile = () => {
  return (
    <div>
      proile
    </div>
  )
}

export default Profile
