import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AdminChat() {
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3000/api/messages')
            .then(response => setMessages(response.data));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3000/api/messages', { user: 'admin', message })
            .then(response => {
                setMessages([...messages, response.data]);
                setMessage('');  // Clear the input after posting the message
            });
    };

    return (
        <div>
            <h1>Admin Chat</h1>
            <div className="chat-box">
                {messages.map((msg, index) => (
                    <div key={index} className={msg.user === 'admin' ? 'my-message' : 'other-message'}>
                        <p><strong>{msg.user}:</strong> {msg.message}</p>
                    </div>
                ))}
            </div>
            <form onSubmit={handleSubmit}>
                <input 
                    type="text" 
                    value={message} 
                    onChange={e => setMessage(e.target.value)} 
                    placeholder="Enter your message here..."
                />
                <button type="submit">Send</button>
            </form>
        </div>
    );
}

export default AdminChat;
