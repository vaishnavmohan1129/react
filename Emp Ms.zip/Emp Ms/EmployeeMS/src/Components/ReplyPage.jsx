import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const ReplyPage = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [reply, setReply] = useState('');

    const handleReplyChange = (e) => {
        setReply(e.target.value);
    };

    const handleReplySubmit = (e) => {
        e.preventDefault();
        
        const issueId = location.state.issueId; // Get the issue ID from the state passed via Link

        axios.post('http://localhost:3000/auth/reply', { id: issueId, reply })
            .then(result => {
                if (result.data.Status) {
                    alert('Reply submitted successfully');
                    navigate('/dashboard'); // Redirect to dashboard or any other page
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.log(err));
    };

    return (
        <div className='px-5 mt-3'>
            <div className='d-flex justify-content-center'>
                <h3>Reply to Issues</h3>
            </div>
            
            <div className='mt-5'>
                <form onSubmit={handleReplySubmit}>
                    <div className='mb-3'>
                        <label htmlFor='replyInput' className='form-label'>Your Reply</label>
                        <textarea
                            id='replyInput'
                            className='form-control'
                            rows='5'
                            value={reply}
                            onChange={handleReplyChange}
                            required
                        ></textarea>
                    </div>
                    <button type='submit' className='btn btn-primary'>Send Reply</button>
                </form>
            </div>
        </div>
    );
};

export default ReplyPage;
