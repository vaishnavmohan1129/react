import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link} from 'react-router-dom'

const ListTask = () => {
    const [task, settask] = useState([])

    useEffect(() => {
        axios.get('http://localhost:3000/auth/taskshow')
        .then(result => {
            console.log(result.data.Result);  
            if (result.data.Status) {
                settask(result.data.Result);
            } else {
                alert(result.data.Error);
            }
        })
        .catch(error => {
            console.error("Error fetching data: ", error);  
        });
    }, []);
    
    
  return (
    <div>
      <div className="px-5 mt-3">
      <div className="d-flex justify-content-center">
        <h3>Task List</h3>
      </div>
      <div className="mt-3">
        <table className="table">
          <thead>
            <tr>
              <th>Task</th>
              <th>Last</th>
              <th>Info</th>
              <th>Emp_id</th>
              
              
            </tr>
          </thead>
          <tbody>
            {task.map((e,i) => (
              <tr key={i}>
                <td>{e.name}</td>
                <td>{e.date}</td>
                <td>{e.info}</td>
               
                
                <td>{e.emp_id}</td>
                
                <td>
               
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
    </div>
  )
}

export default ListTask
