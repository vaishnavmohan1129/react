import React from 'react'

const Templates = () => {
  return (
    <div>
      templa
    </div>
  )
}

export default Templates
