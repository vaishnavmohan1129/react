import React from 'react'

const Images = ({add_image}) => {
  return (
    
       <div className='grid grid-cols-2 gap-2'>
        {
          [1,2,3,4,45,56,87,98,90,34,343,343,45,45,45,45,3,3,4,6,445].map((img,i)=><div key={i}
          onClick={()=>add_image('http://localhost:5173/project.png')}
        className='w-full h-[90px] overflow-hidden rounded-sm cursor-pointer'>
          <img className='w-full h-full object-fill' src={`http://localhost:5173/project.png`}/></div>
          )
        }
       </div>
      
  )
}

export default Images
