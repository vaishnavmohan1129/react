import React from 'react'

const Index = () => {
  return (
    <div>
      hiii
      jgrg
      
    </div>
  )
}

export default Index
