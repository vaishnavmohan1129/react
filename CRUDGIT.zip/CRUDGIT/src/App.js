import './App.css';
import Create from './compoents/Create';
import Read from './compoents/Read';
import Update from './compoents/Update';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <div className="main">
      <h2>CRUD</h2>
    
      <BrowserRouter>
    
      <Routes>
          <Route path="/create" element={<Create />} />
          <Route path="/update" element={<Update />} />
          <Route path="/read" element={<Read />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
