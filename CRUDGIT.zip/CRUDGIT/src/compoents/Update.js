import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { API_URL } from '../constants/URL';
import { useNavigate } from 'react-router-dom';

const Update = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [id, setId] = useState('');
  const navigate = useNavigate();

  const updateeUser = async () => {
    await axios.put(`${API_URL}${id}`, {
      firstName,
      lastName,
    });
    navigate('/read', { state: { refresh: true } });
  };

  useEffect(() => {
    setId(localStorage.getItem('id'));
    setFirstName(localStorage.getItem('firstname'));
    setLastName(localStorage.getItem('lastname'));
  }, []);

  return (
    <div className='form'>
      <label>First Name</label> <br/> <br/>
      <input
        value={firstName}
        onChange={(event) => setFirstName(event.target.value)}
        placeholder='Enter the first name'/>
      <br /> <br />
      <label>Last Name</label>
      <br /> <br />
      <input
        value={lastName}
        onChange={(event) => setLastName(event.target.value)}
        placeholder='Enter the last name'
      />
      <br /> <br />
      <button onClick={updateeUser}>Update</button>
    </div>
  );
};

export default Update;
