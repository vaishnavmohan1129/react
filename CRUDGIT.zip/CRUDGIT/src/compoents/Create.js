import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

import {API_URL} from '../constants/URL'



const Create = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const navigate = useNavigate();

    const postData = async()=>{
        await  axios.post(API_URL,{
            firstName,
            lastName
        })
        navigate('/read')

    }
   


  return (
  <div className='form'>

    <label>First Name</label> <br/> <br/>

    <input  value={firstName} onChange={event => setFirstName(event.target.value)} placeholder='Enter the first name '/><br/> <br/>

    <label>Last Name</label><br/> <br/>

    <input  value={lastName} onChange={event => setLastName(event.target.value)}  placeholder='Enter the lastname'/><br/> <br/>

    <button onClick={postData}>Submit</button>

  </div>
  )
}

export default Create


