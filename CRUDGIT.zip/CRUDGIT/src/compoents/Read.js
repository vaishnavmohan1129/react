import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { API_URL } from '../constants/URL';
import './read.css';
import { useNavigate, useLocation } from 'react-router-dom';

const Read = () => {
  const [apiData, setAPIData] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  const deleteUser = async (id) => {
    await axios.delete(`${API_URL}${id}`);
    callGetAPI();
  };

  const updateeUser = ({ firstName, lastName, id }) => {
    localStorage.setItem('id', id);
    localStorage.setItem('firstname', firstName);
    localStorage.setItem('lastname', lastName);
    navigate('/update');
  };

  const callGetAPI = async () => {
    try {
      const resp = await axios.get(API_URL);
      setAPIData(resp.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    callGetAPI();
  }, [location.state]); 

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Delete</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          {apiData.map((data) => (
            <tr key={data.id}>
              <td>{data.firstName}</td>
              <td>{data.lastName}</td>
              <td>
                <button onClick={() => deleteUser(data.id)}>Delete</button>
              </td>
              <td>
                <button onClick={() => updateeUser(data)}>Update</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Read;
